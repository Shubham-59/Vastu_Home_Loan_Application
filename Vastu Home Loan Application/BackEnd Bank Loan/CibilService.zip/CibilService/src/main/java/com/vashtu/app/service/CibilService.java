package com.vashtu.app.service;

import com.vashtu.app.model.Cibil;

public interface CibilService {

	Cibil getCibilScore();

}
